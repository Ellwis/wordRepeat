package com.example.paya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayaApplicationTests {

    @Test
    void contextLoads() {
    }

}
