package com.example.paya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayaApplication {

    public static void main(String[] args) {
        SpringApplication.run(PayaApplication.class, args);
    }

}
