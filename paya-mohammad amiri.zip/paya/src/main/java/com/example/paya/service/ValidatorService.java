package com.example.paya.service;


import com.example.paya.model.ResponseModel;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
public interface ValidatorService {
    ResponseModel textValidator(HashMap<String , String > entries) throws Exception;
}
