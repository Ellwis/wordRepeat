package com.example.paya.service.impl;


import com.example.paya.model.ResponseModel;
import com.example.paya.service.ValidatorService;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ValidatorServiceImpl implements ValidatorService {
    @Override
    public ResponseModel textValidator(HashMap<String, String> entries) throws Exception {
        ResponseModel responseModel = new ResponseModel();
        if (!entries.entrySet().isEmpty()) {
            HashMap<String, Integer> wordRepeatCount = new HashMap<>();
            for (HashMap.Entry<String, String> entry : entries.entrySet()) {
                String value = entry.getValue();
                if (value != null) {
                    String finalValue = value.toLowerCase().replaceAll("[^\\w\\s]", " ");
                    String[] words = finalValue.split("\\s+");
                    for (String word : words) {
                        if (!word.isEmpty()) {
                            wordRepeatCount.put(word, wordRepeatCount.getOrDefault(word, 0) + 1);
                        }
                    }
                }
            }
            responseModel.setContent(wordRepeatCount);
            responseModel.setMessage(HttpStatus.OK.toString());
            return responseModel;
        } else {
            responseModel.setContent(HttpStatus.BAD_REQUEST);
            responseModel.setMessage("entry value cannot be null");
            return responseModel;
        }
    }

}
