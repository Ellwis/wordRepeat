package com.example.paya.model;


import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class ResponseModel implements Serializable {
    private String message;
    private Object content;

}
