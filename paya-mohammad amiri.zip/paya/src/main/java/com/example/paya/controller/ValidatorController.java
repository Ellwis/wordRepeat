package com.example.paya.controller;


import com.example.paya.model.ResponseModel;
import com.example.paya.service.ValidatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

@RestController
@RequestMapping(value = "/validator")
public class ValidatorController {

    @Autowired
    ValidatorService validatorService;

    @PostMapping(value = "/validationService")
    public ResponseEntity<ResponseModel> validationController(@RequestBody HashMap<String, String> entries) throws Exception {
        try {
            ResponseModel responseModel = validatorService.textValidator(entries);
            return ResponseEntity.ok().body(responseModel);

        } catch (Exception e) {
            ResponseModel responseModel = new ResponseModel();
            responseModel.setMessage(e.getMessage());
            return ResponseEntity.badRequest().body(responseModel);
        }
    }
}
